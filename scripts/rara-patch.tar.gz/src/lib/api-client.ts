// Rara — Client-side API helpers + device fingerprint collector
//
// Device fingerprint collection is INVISIBLE to the user — it runs on the
// login screen while the captcha loads. The signals are hashed client-side
// (so the server only sees a hash, not raw data) and sent on EVERY API
// request via the X-KFAI-Device header. The server verifies the hash
// matches the one bound to the session; if not, the session is revoked.
//
// Anti-scraping measures built into the fingerprint:
//   - Canvas rendering (unique per GPU/driver combo)
//   - WebGL renderer string (vendor + model)
//   - Audio context fingerprint (signal processing differences)
//   - Font list (system + installed fonts)
//   - Timezone + language + screen resolution + color depth
//   - Plugin list + MIME types
//   - Performance timing (sub-millisecond CPU differences)
//
// A bot without a real browser cannot reproduce all of these — and even
// headless browsers leave a different fingerprint than real users.

const TOKEN_KEY = 'kfai_token';
const COOKIE_NAME = 'kfai_session';

// ── Cookie helpers ──────────────────────────────────────────────────────────
// Cookies survive across tabs and browser restarts (unlike localStorage which
// can be cleared). We store the session token in BOTH localStorage and a cookie
// so that opening a new tab or clearing localStorage doesn't generate a new
// user identity.
function setCookie(name: string, value: string, days: number): void {
  if (typeof document === 'undefined') return;
  const expires = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toUTCString();
  const secure = location.protocol === 'https:' ? '; Secure' : '';
  document.cookie = `${name}=${encodeURIComponent(value)}; expires=${expires}; path=/; SameSite=Lax${secure}`;
}

function getCookie(name: string): string | null {
  if (typeof document === 'undefined') return null;
  const match = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
  return match ? decodeURIComponent(match[1]) : null;
}

function deleteCookie(name: string): void {
  if (typeof document === 'undefined') return;
  document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=/; SameSite=Lax`;
}

// ── Token helpers (localStorage + cookie dual storage) ──────────────────────
export function getToken(): string | null {
  if (typeof window === 'undefined') return null;
  // Try localStorage first, then fall back to cookie
  const local = window.localStorage.getItem(TOKEN_KEY);
  if (local) return local;
  const cookie = getCookie(COOKIE_NAME);
  if (cookie) {
    // Restore to localStorage from cookie
    window.localStorage.setItem(TOKEN_KEY, cookie);
    return cookie;
  }
  return null;
}

export function setToken(token: string): void {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(TOKEN_KEY, token);
  // Also store in cookie (30 days) for cross-tab persistence
  setCookie(COOKIE_NAME, token, 30);
}

export function clearToken(): void {
  if (typeof window === 'undefined') return;
  window.localStorage.removeItem(TOKEN_KEY);
  deleteCookie(COOKIE_NAME);
}

// ── Device fingerprint collector ────────────────────────────────────────────
// Collects ~12 signals from the browser. The hash is stable per-device but
// changes if any signal changes (e.g. user opens devtools, switches language).
//
// We compute SHA-256 client-side using the Web Crypto API so the server only
// ever sees the hash. The raw signals are sent only on login (server hashes
// them again to verify) — subsequent requests just send the hash in a header.

let cachedFingerprint: string | null = null;
let cachedRawSignals: Record<string, string> | null = null;

async function sha256Hex(s: string): Promise<string> {
  const buf = new TextEncoder().encode(s);
  const hash = await crypto.subtle.digest('SHA-256', buf);
  return Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, '0')).join('');
}

function getCanvasFingerprint(): string {
  try {
    const canvas = document.createElement('canvas');
    canvas.width = 240;
    canvas.height = 60;
    const ctx = canvas.getContext('2d');
    if (!ctx) return 'no-canvas';
    // Draw text + shapes — the rendering varies by GPU/driver/font availability
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillStyle = '#f60';
    ctx.fillRect(10, 5, 80, 20);
    ctx.fillStyle = '#069';
    ctx.fillText('Rara fp · 2026 · abcdefg', 5, 25);
    ctx.strokeStyle = 'rgba(102,204,0,0.7)';
    ctx.beginPath();
    ctx.arc(50, 30, 20, 0, Math.PI * 2);
    ctx.stroke();
    return canvas.toDataURL();
  } catch {
    return 'canvas-error';
  }
}

function getWebGLFingerprint(): { vendor: string; renderer: string } {
  try {
    const canvas = document.createElement('canvas');
    const gl = (canvas.getContext('webgl') || canvas.getContext('experimental-webgl')) as WebGLRenderingContext | null;
    if (!gl) return { vendor: 'no-webgl', renderer: 'no-webgl' };
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    if (!ext) return { vendor: 'no-ext', renderer: 'no-ext' };
    return {
      vendor: String(gl.getParameter(ext.UNMASKED_VENDOR_WEBGL) || ''),
      renderer: String(gl.getParameter(ext.UNMASKED_RENDERER_WEBGL) || ''),
    };
  } catch {
    return { vendor: 'err', renderer: 'err' };
  }
}

async function getAudioFingerprint(): Promise<string> {
  try {
    const AC = (window as any).OfflineAudioContext || (window as any).webkitOfflineAudioContext;
    if (!AC) return 'no-audio';
    const ctx = new AC(1, 44100, 44100);
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.value = 10000;
    const comp = ctx.createDynamicsCompressor();
    osc.connect(comp);
    comp.connect(ctx.destination);
    osc.start(0);
    const buf = await ctx.startRendering();
    // Sample a few points — these differ subtly per CPU/soundcard
    const channel = buf.getChannelData(0);
    let sum = 0;
    for (let i = 4500; i < 5000; i++) sum += Math.abs(channel[i] || 0);
    return sum.toFixed(20);
  } catch {
    return 'audio-err';
  }
}

function getFontList(): string {
  try {
    const fonts = [
      'Arial', 'Helvetica', 'Times', 'Courier', 'Verdana', 'Georgia', 'Palatino',
      'Garamond', 'Bookman', 'Comic Sans MS', 'Trebuchet MS', 'Arial Black',
      'Impact', 'Sans-serif', 'Serif', 'Monospace', 'Cursive', 'Fantasy',
      'Roboto', 'Inter', 'JetBrains Mono', 'Menlo', 'Consolas', 'Source Code Pro',
      'Ubuntu', 'DejaVu Sans', 'Liberation Sans', 'Noto Sans', 'Noto Serif',
    ];
    const testStr = 'mmmmmmmmmmlli';
    const testSize = '72px';
    const baseFonts = ['monospace', 'sans-serif', 'serif'];
    const span = document.createElement('span');
    span.style.fontSize = testSize;
    span.style.position = 'absolute';
    span.style.width = 'auto';
    span.style.height = 'auto';
    span.style.visibility = 'hidden';
    span.style.whiteSpace = 'nowrap';
    document.body.appendChild(span);

    const baseWidths: Record<string, number> = {};
    const baseHeights: Record<string, number> = {};
    for (const b of baseFonts) {
      span.style.fontFamily = b;
      span.textContent = testStr;
      baseWidths[b] = span.offsetWidth;
      baseHeights[b] = span.offsetHeight;
    }

    const detected: string[] = [];
    for (const font of fonts) {
      let isDetected = false;
      for (const b of baseFonts) {
        span.style.fontFamily = `'${font}',${b}`;
        span.textContent = testStr;
        if (span.offsetWidth !== baseWidths[b] || span.offsetHeight !== baseHeights[b]) {
          isDetected = true;
          break;
        }
      }
      if (isDetected) detected.push(font);
    }
    document.body.removeChild(span);
    return detected.join(',');
  } catch {
    return 'font-err';
  }
}

export async function collectDeviceFingerprint(): Promise<{ hash: string; raw: Record<string, string> }> {
  if (cachedFingerprint && cachedRawSignals) {
    return { hash: cachedFingerprint, raw: cachedRawSignals };
  }
  const raw: Record<string, string> = {};

  // ── FAST FINGERPRINT ONLY (for login) ──────────────────────────────────────
  // All SYNCHRONOUS — no async waits, no timeouts, no hangs.
  // The full 100+ signal fingerprint is collected in background after login.

  raw.canvas = getCanvasFingerprint().slice(0, 200);
  const gl = getWebGLFingerprint();
  raw.glVendor = gl.vendor;
  raw.glRenderer = gl.renderer;
  raw.fonts = getFontList();
  raw.screen = `${screen.width}x${screen.height}x${screen.colorDepth}x${screen.pixelDepth || 0}`;
  raw.availScreen = `${screen.availWidth}x${screen.availHeight}`;
  raw.devicePixelRatio = String(window.devicePixelRatio || 1);
  raw.innerWidth = `${window.innerWidth}x${window.innerHeight}`;
  raw.tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'unknown';
  raw.tzOffset = String(new Date().getTimezoneOffset());
  raw.lang = navigator.language || 'unknown';
  raw.langs = (navigator.languages || []).join(',');
  raw.platform = navigator.platform || 'unknown';
  raw.cpuCores = String((navigator as any).hardwareConcurrency || 0);
  raw.memGB = String((navigator as any).deviceMemory || 0);
  raw.maxTouch = String(navigator.maxTouchPoints || 0);
  raw.touch = String(('ontouchstart' in window) || navigator.maxTouchPoints > 0);
  raw.math = `${Math.tan(-1e300)},${Math.sinh(1)},${Math.cosh(10)},${Math.expm1(1)}`;
  try {
    raw.plugins = Array.from(navigator.plugins || []).map((p) => p.name).join(',') || 'none';
  } catch { raw.plugins = 'err'; }
  try {
    const uaData = (navigator as any).userAgentData;
    if (uaData) {
      raw.uaMobile = String(uaData.mobile || false);
      raw.uaPlatform = uaData.platform || 'unknown';
    }
  } catch {}
  try {
    const t = performance.now();
    let sum = 0;
    for (let i = 0; i < 1000; i++) sum += Math.sqrt(i);
    raw.perfLoop = String(performance.now() - t);
  } catch {}

  // ── Compute hash (v5 — fast fingerprint only) ───────────────────────────────
  const sorted = Object.keys(raw).sort().map((k) => `${k}=${raw[k]}`).join('|');
  const hash = await sha256Hex('kfai-fp-v5:' + sorted);
  cachedFingerprint = hash;
  cachedRawSignals = raw;
  return { hash, raw };
}
// ── Behavioral biometrics (separate from device fingerprint) ──────────────────
// Collected only on login screen — measures how the user moves their mouse
// and types. Used as a SECOND factor beyond device fingerprint.
let behavioralData: { mouseMoves: number; mouseVelocities: number[]; keyTimings: number[]; scrollEvents: number; touchEvents: number } = {
  mouseMoves: 0, mouseVelocities: [], keyTimings: [], scrollEvents: 0, touchEvents: 0,
};
let behaviorTrackingActive = false;

export function startBehavioralTracking() {
  if (behaviorTrackingActive) return;
  behaviorTrackingActive = true;
  let lastMouseTime = 0;
  let lastMouseX = 0;
  let lastMouseY = 0;
  let lastKeyTime = 0;

  window.addEventListener('mousemove', (e) => {
    const now = performance.now();
    if (lastMouseTime > 0) {
      const dt = now - lastMouseTime;
      const dx = e.clientX - lastMouseX;
      const dy = e.clientY - lastMouseY;
      const dist = Math.sqrt(dx * dx + dy * dy);
      const vel = dt > 0 ? dist / dt : 0;
      behavioralData.mouseVelocities.push(Math.round(vel * 100) / 100);
      if (behavioralData.mouseVelocities.length > 50) behavioralData.mouseVelocities.shift();
    }
    lastMouseTime = now;
    lastMouseX = e.clientX;
    lastMouseY = e.clientY;
    behavioralData.mouseMoves++;
  }, { passive: true });

  window.addEventListener('keydown', () => {
    const now = performance.now();
    if (lastKeyTime > 0) {
      const dt = now - lastKeyTime;
      if (dt < 5000) behavioralData.keyTimings.push(Math.round(dt));
      if (behavioralData.keyTimings.length > 20) behavioralData.keyTimings.shift();
    }
    lastKeyTime = now;
  }, { passive: true });

  window.addEventListener('wheel', () => { behavioralData.scrollEvents++; }, { passive: true });
  window.addEventListener('touchstart', () => { behavioralData.touchEvents++; }, { passive: true });
}

export function getBehavioralSignature(): string {
  const v = behavioralData.mouseVelocities;
  const avgVel = v.length ? v.reduce((a, b) => a + b, 0) / v.length : 0;
  const variance = v.length ? v.reduce((a, b) => a + (b - avgVel) ** 2, 0) / v.length : 0;
  const k = behavioralData.keyTimings;
  const avgKey = k.length ? k.reduce((a, b) => a + b, 0) / k.length : 0;
  return `m:${behavioralData.mouseMoves},v:${avgVel.toFixed(2)},var:${variance.toFixed(2)},k:${behavioralData.keyTimings.length},kt:${avgKey.toFixed(0)},s:${behavioralData.scrollEvents},t:${behavioralData.touchEvents}`;
}

// ── Auth headers helper ──────────────────────────────────────────────────────
// Adds Authorization + X-KFAI-Device to every request.
// The device fingerprint is computed once and cached.
export async function authHeaders(extra?: HeadersInit): Promise<HeadersInit> {
  const token = getToken();
  const { hash } = await collectDeviceFingerprint();
  const h: Record<string, string> = { ...(extra as Record<string, string> || {}) };
  if (token) h['Authorization'] = `Bearer ${token}`;
  h['X-KFAI-Device'] = hash;
  return h;
}

// Sync version that uses cached fingerprint (or empty if not yet computed)
export function authHeadersSync(extra?: HeadersInit): HeadersInit {
  const token = getToken();
  const h: Record<string, string> = { ...(extra as Record<string, string> || {}) };
  if (token) h['Authorization'] = `Bearer ${token}`;
  if (cachedFingerprint) h['X-KFAI-Device'] = cachedFingerprint;
  return h;
}

// ── Auth ──────────────────────────────────────────────────────────────────────
export type AuthMe = {
  userId: string;
  authId: string;
  displayName: string | null;
  createdAt: string;
  lastSeenAt: string;
};

export type LoginResponse = {
  token: string;
  authId: string;
  userId: string;
  displayName: string | null;
  createdAt: string;
  expiresInDays: number;
};

export async function fetchCaptcha(): Promise<{ challengeId: string; svg: string; expiresAt: string }> {
  const res = await fetch('/api/captcha', { cache: 'no-store' });
  if (!res.ok) {
    if (res.status === 429) {
      const j = await res.json().catch(() => ({}));
      throw new Error(j.error || 'Terlalu banyak permintaan captcha. Coba lagi nanti.');
    }
    if (res.status === 502) throw new Error('Akses ditolak.');
    throw new Error('Gagal memuat captcha');
  }
  return res.json();
}

// ── Login (device-bound, no captcha) ──────────────────────────────────────────
// User just clicks "Masuk" — server validates:
//   1. Device fingerprint hash is present and well-formed
//   2. Raw signals match the hash (server re-hashes to verify)
//   3. Honeypot field is empty (bot check)
//   4. Time-trap: form took at least 1.5s to submit (bot check)
//   5. Behavioral signature present (mouse movements, key timings)
//   6. Bot UA check
//   7. Rate limit per IP (10 logins/hour)
//   8. 1 IP = 1 session (revoke prior sessions for same IP)
export async function login(renderTimestamp: number): Promise<LoginResponse> {
  const { hash, raw } = await collectDeviceFingerprint();
  const behavior = getBehavioralSignature();
  const body: Record<string, unknown> = {
    _ts: renderTimestamp,
    _fp: hash,
    _fs: raw,
    _bh: behavior,
    _hp: '',
  };
  // Timeout: 15s — if Cloudflare/network is slow, abort and retry
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const res = await fetch('/api/auth', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
      signal: controller.signal,
    });
    clearTimeout(timeoutId);

    // ── Distinguish Cloudflare edge 502 from Next.js origin 502 ────────────
    // Cloudflare Bot Fight Mode / managed challenge returns a plain-text
    // "error code: 502" body (with `server: cloudflare` header) BEFORE the
    // request reaches our Next.js server. Next.js's own bot-UA check returns
    // a "Bad Gateway" body. The two have identical status (502) but different
    // bodies — we need to read the raw text to tell them apart.
    if (res.status === 502) {
      const rawBody = await res.text().catch(() => '');
      if (rawBody.includes('error code') || rawBody.toLowerCase().includes('cloudflare')) {
        // Cloudflare edge block (Bot Fight Mode, Under Attack, or managed challenge)
        const err = new Error(
          'Cloudflare sedang menantang browser kamu (edge 502). Coba refresh halaman, nonaktifkan ekstensi privacy (uBlock, DuckDuckGo, Privacy Badger), atau pakai browser lain. Jika tetap gagal, minta admin disable Bot Fight Mode di Cloudflare dashboard untuk zone rara.ai.id.'
        );
        (err as any).isCloudflare = true;
        throw err;
      }
      // Next.js origin 502 (isBotUserAgent returned true)
      throw new Error('Akses ditolak oleh server. Coba refresh halaman atau pakai browser lain.');
    }

    const j = await res.json().catch(() => ({}));
    if (!res.ok) {
      if (res.status === 429) throw new Error(j.error || 'Terlalu banyak percobaan login. Coba lagi nanti.');
      if (res.status === 403) throw new Error(j.error || 'Verifikasi perangkat gagal.');
      throw new Error(j.error || `Login gagal (${res.status})`);
    }
    return j as LoginResponse;
  } catch (e: any) {
    clearTimeout(timeoutId);
    if (e?.name === 'AbortError') {
      throw new Error('Login timeout — koneksi lambat. Mencoba lagi...');
    }
    throw e;
  }
}

export async function fetchMe(): Promise<AuthMe | null> {
  const token = getToken();
  if (!token) return null;
  const res = await fetch('/api/auth', { headers: await authHeaders() });
  if (res.status === 401) {
    clearToken();
    return null;
  }
  if (!res.ok) return null;
  return res.json();
}

export async function logout(): Promise<void> {
  try {
    await fetch('/api/auth', { method: 'PATCH', headers: await authHeaders() });
  } catch { /* ignore */ }
  clearToken();
}

// ── Conversations ─────────────────────────────────────────────────────────────
export type Conversation = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messageCount: number;
};

export type ConversationDetail = {
  id: string;
  title: string;
  createdAt: string;
  updatedAt: string;
  messages: Array<{
    id: string;
    role: 'user' | 'assistant' | 'system' | 'tool';
    content: string;
    toolCalls: unknown;
    toolCallId: string | null;
    createdAt: string;
  }>;
};

export async function listConversations(): Promise<Conversation[]> {
  const res = await fetch('/api/conversations', { headers: await authHeaders() });
  if (!res.ok) throw new Error('Failed to list conversations');
  const j = await res.json();
  return j.conversations || [];
}

export async function createConversation(title?: string): Promise<Conversation> {
  const res = await fetch('/api/conversations', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
    body: JSON.stringify({ title: title || 'New conversation' }),
  });
  if (!res.ok) throw new Error('Failed to create conversation');
  return res.json();
}

export async function getConversation(id: string): Promise<ConversationDetail> {
  const res = await fetch(`/api/conversations/${encodeURIComponent(id)}`, { headers: await authHeaders() });
  if (!res.ok) throw new Error('Failed to load conversation');
  return res.json();
}

export async function deleteConversation(id: string): Promise<void> {
  const res = await fetch(`/api/conversations/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: await authHeaders(),
  });
  if (!res.ok) throw new Error('Failed to delete conversation');
}

// ── Chat (returns a streaming Response) ────────────────────────────────────────
// Supports optional image attachments (filenames from /api/upload).
export async function postChat(
  message: string,
  conversationId?: string | null,
  imageAttachments?: string[],
): Promise<Response> {
  const body: Record<string, unknown> = { message, conversationId: conversationId || null };
  if (imageAttachments && imageAttachments.length > 0) {
    body.imageAttachments = imageAttachments;
  }
  return fetch('/api/chat', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...(await authHeaders()) },
    body: JSON.stringify(body),
  });
}

// ── Image upload ──────────────────────────────────────────────────────────────
export type UploadedImage = {
  ok: boolean;
  filename: string;          // sandbox path (e.g. "uploads/abc.png")
  originalName: string;
  mimeType: string;
  size: number;
  width?: number;
  height?: number;
  dataUrl: string;           // base64 data URL (for preview)
  downloadUrl: string;
};

export async function uploadImage(file: File): Promise<UploadedImage> {
  const formData = new FormData();
  formData.append('image', file);
  const res = await fetch('/api/upload', {
    method: 'POST',
    headers: await authHeaders(),
    body: formData,
  });
  const j = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(j.error || `Upload failed (${res.status})`);
  return j as UploadedImage;
}
